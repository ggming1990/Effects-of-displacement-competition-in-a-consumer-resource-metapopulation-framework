function output=antagon1(~,rho,Tij,ri,mi,ei,n_m,ui,ci)
rho(rho<eps)=0;
%% 
A_all2=sum(rho(n_m+1:2*n_m));
%% 
mu2=ui.*rho(1:n_m);    
%% pairwise resources
pw=sum(rho(n_m+1:2*n_m)*rho(n_m+1:2*n_m)'.*Tij,2);
%% 
output(1:n_m,1) = sum(ri.*rho(1:n_m)).*(rho(n_m+1:2*n_m)-rho(1:n_m))-mi.*rho(1:n_m);  %
output(n_m+1:2*n_m,1) = ci.*rho(n_m+1:2*n_m).*(1-A_all2)-ei.*rho(n_m+1:2*n_m)+pw-mu2;    %





                                                 