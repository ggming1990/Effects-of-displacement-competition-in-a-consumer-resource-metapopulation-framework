clear
clc
tic
n_m=50;% 
rp=20;% 
rho_all=zeros(1+n_m,rp);% 
%% 
f_all=0:0.05:1;% 
c=1; %
e=0.1;%
ri=unifrnd(0.8,1,n_m,1);%
mi=unifrnd(0,0.1,n_m,1);%
RI_all=zeros(length(f_all),rp);% 
H_1=cell(length(f_all),1);% 
H_all=cell(length(f_all),rp);% 
final_species=zeros(length(f_all),rp);% 
final_species1=zeros(length(f_all),rp);% 
for cyc=1:rp
    %% 
    t0=[0,10000];    %
    a11=rand(n_m,1);
    initial_value_m=a11/sum(a11);
    initial_value_i=1.2*max(initial_value_m);
    rho0=[initial_value_i;initial_value_m];%
    rho_all(:,cyc)=rho0;
    %% 
    for R=1:length(f_all)
        f=f_all(R);
        H=triu(ones(n_m),1);H=H+diag(ones(n_m,1)*0.5);
        a1=rand(n_m);%
        for i=1:n_m-1
            for j=i+1:n_m
                if a1(i,j)<f && rand(1)<0.5
                    H(i,j)=0;H(j,i)=1;
                end
            end
        end
        H_1{R}=H;
        %% 
        H01=H-diag(ones(n_m,1)*0.5);
        var2=1/n_m*sum((sum(H01,2)-1/n_m*sum(H01(:))).^2);
        if mod(n_m,2)==0 %
            RI=1-(var2-0.25)/((n_m^2-1)/12-0.25);
        else
            RI=1-var2/((n_m^2-1)/12);
        end
        RI_all(R,cyc)=RI;% 
        %% Tij
        Tij=repmat(ri,1,n_m).*H-repmat(ri',n_m,1).*H';
        %% 
        [t,rho]=ode45(@(t,rho)antagon1(t,rho,Tij,c,e,mi,n_m,ri),t0,rho0);  %
        %% 
        aam1 = rho(end-10:end,2:n_m+1);
        aam=length(find(mean(aam1)>1e-4));
        final_species(R,cyc)=aam/n_m;
        %% 
        aam2 = rho(end-10:end,1);
        if mean(aam2)>1e-4
            final_species1(R,cyc)=1;
        else
            final_species1(R,cyc)=0;
        end
    end
    H_all(:,cyc)= H_1;
end
RI_all=reshape(RI_all,[],1);
pair_mean=mean(final_species(:,:),2);% 
pair_std=std(final_species(:,:),0,2);
pairwise=reshape(final_species(:,:),[],1);
figure(1),plot(RI_all,pairwise,'go')
save H2
