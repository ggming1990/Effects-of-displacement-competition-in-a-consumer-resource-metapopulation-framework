function output=antagon1(~,rho,Tij,c,e,mi,n_m,ui,ri)
rho(rho<1e-4)=0;
A_all2=sum(rho(2:1+n_m));
%% 
mu2=ui.*rho(2:1+n_m);    
%% pairwise consumers
pw=sum(rho(2:1+n_m)*rho(2:1+n_m)'.*Tij,2);
%% 
output(1,1) = c.*rho(1).*(1-rho(1))-e.*rho(1)-sum(mu2);  %resources
output(2:1+n_m,1) = ri.*rho(2:1+n_m).*(rho(1)-A_all2)-mi.*rho(2:1+n_m)+pw;    %consumers





                                                 