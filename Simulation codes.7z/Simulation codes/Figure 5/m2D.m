clear
clc
tic
n_m=50;% 
rp=20;%
rho_all=zeros(1+n_m,rp);%
%% 
f=0.8;% 
c=1; %
e=0.1;%
r0=0.5;r_diff=0:0.01:0.5;%
sigma_all=zeros(length(r_diff),rp);%
mi=unifrnd(0.1,0.1,n_m,1);%
RI_all=zeros(length(r_diff),rp);% 
H_1=cell(1,rp);% 
H_all=cell(length(r_diff),rp);% 
final_species=zeros(length(r_diff),rp);% 
final_species1=zeros(length(r_diff),rp);% 
for cyc=1:length(r_diff)
    for repeat=1:rp
        RI=RI_all(cyc,repeat);
        while RI<0.9||RI>0.95  %
            H=triu(ones(n_m),1);H=H+diag(ones(n_m,1)*0.5);
            a1=rand(n_m);%
            for i=1:n_m-1
                for j=i+1:n_m
                    if a1(i,j)<f && rand(1)<0.5
                        H(i,j)=0;H(j,i)=1;
                    end
                end
            end
            H1=H-diag(ones(n_m,1)*0.5);%
            var=1/n_m*sum((sum(H1,2)-1/n_m*sum(H1(:))).^2);
            if mod(n_m,2)==0 %
                RI=1-(var-0.25)/((n_m^2-1)/12-0.25);
            else
                RI=1-var/((n_m^2-1)/12);
            end
        end
        RI_all(cyc,repeat)=RI;
        r_cha=r_diff(cyc);
        ri=unifrnd(r0-r_cha,r0+r_cha,n_m,1);%
        sigma_all(cyc,repeat)=(2*r_cha)/sqrt(12);%
        H_1{repeat}=H;
        %% 
        t0=[0,10000];    %
        a11=rand(n_m,1);
        initial_value_m=a11/sum(a11);
        initial_value_i=1.2*max(initial_value_m);
        rho0=[initial_value_i;initial_value_m];%
        rho_all(:,repeat)=rho0;
        %% Tij
        Tij=repmat(ri,1,n_m).*H-repmat(ri',n_m,1).*H';
        %% 
        [t,rho]=ode45(@(t,rho)antagon1(t,rho,Tij,c,e,mi,n_m,ri),t0,rho0);  %�Կ�
        %% 
        aam1 = rho(end-10:end,2:n_m+1);
        aam=length(find(mean(aam1)>1e-4));
        final_species(cyc,repeat)=aam/n_m;
        %% 
        aam2 = rho(end-10:end,1);
        if mean(aam2)>1e-4
            final_species1(cyc,repeat)=1;
        else
            final_species1(cyc,repeat)=0;
        end
    end
    H_all(cyc,:)= H_1;
end
sigma_all=reshape(sigma_all,[],1);
pair_mean=mean(final_species(:,:),2);%
pair_std=std(final_species(:,:),0,2);
pairwise=reshape(final_species(:,:),[],1);
figure(3),plot(sigma_all,pairwise,'go')
save H4
