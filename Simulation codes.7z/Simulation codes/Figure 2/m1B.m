clear
clc
tic
n_m1=10:5:100;% 
rp=20;% 
%% 
f=0.8;% 
RI_all=zeros(length(n_m1),rp);% 
H_1=cell(1,rp);% 
H_all=cell(length(n_m1),rp);% 
final_species=zeros(length(n_m1),rp);% 
final_species1=zeros(length(n_m1),rp);% 
for cyc=1:length(n_m1)
    n_m=n_m1(cyc);
    ci=unifrnd(0.8,1,n_m,1);% 
    ei=unifrnd(0,0.1,n_m,1);% 
    ri=unifrnd(0.8,1,n_m,1);% 
    mi=unifrnd(0,0.1,n_m,1);% 
    for repeat=1:rp
        RI=RI_all(cyc,repeat);
        while RI<0.9||RI>0.95  %
            H=triu(ones(n_m),1);H=H+diag(ones(n_m,1)*0.5);
            a1=rand(n_m);%
            for i=1:n_m-1
                for j=i+1:n_m
                    if a1(i,j)<f && rand(1)<0.5
                        H(i,j)=0;H(j,i)=1;
                    end
                end
            end
            H_1{repeat}=H;
            H1=H-diag(ones(n_m,1)*0.5);%
            var=1/n_m*sum((sum(H1,2)-1/n_m*sum(H1(:))).^2);
            if mod(n_m,2)==0 %
                RI=1-(var-0.25)/((n_m^2-1)/12-0.25);
            else
                RI=1-var/((n_m^2-1)/12);
            end
        end
        RI_all(cyc,repeat)=RI;
        %% 
        a11=rand(n_m,1);
        initial_value_m=a11/sum(a11);
        initial_value_i=0.8*min(initial_value_m);
        a12=rand(n_m,1);
        A=a12/sum(a12);
        rho0=[initial_value_i;initial_value_m];%
        t0=[0,10000];% 
        %% Tij
        Tij=repmat(ci,1,n_m).*H-repmat(ci',n_m,1).*H';
        %% 
        [t,rho]=ode45(@(t,rho)antagon1(t,rho,ci,ei,ri,n_m,mi,Tij,A),t0,rho0);
        %% 
        aam1 = rho(end-10:end,2:n_m+1);
        aam=length(find(mean(aam1)>1e-4));
        final_species(cyc,repeat)=aam/n_m;
        %% 
        aam2 = rho(end-10:end,1);
        if mean(aam2)>1e-4
            final_species1(cyc,repeat)=1;
        else
            final_species1(cyc,repeat)=0;
        end
    end
    H_all(cyc,:)= H_1;
end
n_array=repmat(n_m1',rp,1);
pair_mean=mean(final_species(:,:),2);% 
pair_std=std(final_species(:,:),0,2);
pairwise=reshape(final_species(:,:),[],1);
figure(7),plot(n_array,pairwise,'go')
save N7

