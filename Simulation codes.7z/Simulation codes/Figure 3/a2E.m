clear
clc
tic
n_m=50;% 
rp=20;% 
%% 
s_length=0:0.01:0.5;
c=1; %
e=0.1;%
sigma_all=zeros(length(s_length),rp);% 
final_species=zeros(length(s_length),rp);% 
final_species1=zeros(length(s_length),rp);% 
CV_all=zeros(length(s_length),rp);
for repeat=1:rp
    ri=unifrnd(0.8,1,n_m,1);%
    mi=unifrnd(0,0.1,n_m,1);%
    ui=unifrnd(0,0.1,n_m,1);  %
    for cyc=1:length(s_length)
        A=[ones(1225,1)*(0.5-s_length(cyc));ones(1225,1)*(0.5+s_length(cyc))];
        id=randperm(2450);A1=A(id);
        H1=diag(ones(n_m,1));H1(H1==0)=A1;
        H=triu(H1,1);H2=triu(1-H,1);H=H+H2'+diag(ones(n_m,1)*0.5);%
        CV_all(cyc,repeat)=std(H(:))/mean(H(:));
        %%
        t0=[0,10000];    %
        a11=rand(n_m,1);
        initial_value_m=a11/sum(a11);
        initial_value_i=1.2*max(initial_value_m);
        rho0=[initial_value_i;initial_value_m];%
        %% Tij
        Tij=repmat(ri,1,n_m).*H-repmat(ri',n_m,1).*H';
        %% 
        [t,rho]=ode45(@(t,rho)antagon1(t,rho,Tij,c,e,mi,n_m,ui,ri),t0,rho0);  %
        %% 
        aam1 = rho(end-999:end,2:n_m+1);
        aam=length(find(mean(aam1)>1e-4));
        final_species(cyc,repeat)=aam/n_m;
        %% 
        aam2 = rho(end-999:end,1);
        if mean(aam2)>1e-4
            final_species1(cyc,repeat)=1;
        else
            final_species1(cyc,repeat)=0;
        end
    end
    
end
CV_all=reshape(CV_all,[],1);
pair_mean=mean(final_species(:,:),2);%
pair_std=std(final_species(:,:),0,2);
pairwise=reshape(final_species(:,:),[],1);
figure(11),plot(CV_all,pairwise,'go')
save D12
