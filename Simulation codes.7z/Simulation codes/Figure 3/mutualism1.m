function output=antagon1(~,rho,ci,ei,ri,n_m,mi,Tij,A)
rho(rho<eps)=0;
A_all2=sum(rho(2:n_m+1));
%% pairwise resources
pw=sum((rho(1).*A)*rho(2:n_m+1)'.*Tij,2);
%% 
output(1,1) = sum(sum(ri.*rho(1).*A).*(rho(2:n_m+1)-rho(1).*A)-mi.*rho(1).*A);  %consumers
output(2:n_m+1,1) = ci.*rho(1).*A.*(1-A_all2)-ei.*rho(2:n_m+1)+pw;    %resources





