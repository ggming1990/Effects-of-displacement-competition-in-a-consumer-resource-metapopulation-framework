clear
clc
n_m=50; % 
rp=20;%
s_length=0:0.01:0.5;
CV_all=zeros(length(s_length),rp);
RI_all=zeros(length(s_length),rp);
var_all=zeros(length(s_length),rp);
var_max_all=zeros(length(s_length),rp);
var_min_all=zeros(length(s_length),rp);
for repeat=1:rp
    for cyc=1:length(s_length)
        A=[ones(1225,1)*(0.5-s_length(cyc));ones(1225,1)*(0.5+s_length(cyc))];
        id=randperm(2450);A1=A(id);
        H1=diag(ones(n_m,1));H1(H1==0)=A1;
        H=triu(H1,1);H2=triu(1-H,1);H=H+H2';%
        CV_all(cyc,repeat)=std(H(:))/mean(H(:));
        var=1/n_m*sum((sum(H,2)-1/n_m*sum(H(:))).^2);%
        H_max_1=triu(ones(n_m)*(0.5+s_length(cyc)),1);
        H_max_2=triu(ones(n_m)*(0.5-s_length(cyc)),1);
        H_max=H_max_1+H_max_2';
        var_max=1/n_m*sum((sum(H_max,2)-1/n_m*sum(H_max(:))).^2);%calculating Var_max
        min1=ones(25,1)*(24+0.5-s_length(cyc));
        min2=ones(25,1)*(24+0.5+s_length(cyc));min_all=[min1;min2];
        var_min=1/n_m*sum((min_all-1/n_m*sum(H_max(:))).^2);%calculating Var_min
        RI=1-((var-var_min)/(var_max-var_min));%calculating RI
        RI_all(cyc,repeat)=RI;
        var_all(cyc,repeat)=var;
        var_max_all(cyc,repeat)=var_max;
        var_min_all(cyc,repeat)=var_min;
    end
end
CV_all=reshape(CV_all,[],1);
RI_all=reshape(RI_all,[],1);
figure(14),plot(CV_all,RI_all,'ko')
save M14



