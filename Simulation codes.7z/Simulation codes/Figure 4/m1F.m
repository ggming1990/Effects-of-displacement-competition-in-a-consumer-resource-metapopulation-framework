clear
clc
tic
n_m=50;% 
rp=20;%
%% 
s_length=0:0.01:0.5;
sigma_all=zeros(length(s_length),rp);% 
final_species=zeros(length(s_length),rp);% 
final_species1=zeros(length(s_length),rp);% 
for repeat=1:rp
    ci=unifrnd(0.8,1,n_m,1);% 
    ei=unifrnd(0,0.1,n_m,1);% 
    ri=unifrnd(0.8,1,n_m,1);% 
    mi=unifrnd(0,0.1,n_m,1);% 
    for cyc=1:length(s_length)
        H1=unifrnd(0.5-s_length(cyc),0.5+s_length(cyc),n_m,n_m);
        H=triu(H1,1);H=H+diag(ones(n_m,1)*0.5);
        H2=triu(1-H,1);H=H+H2';
        sigma_all(cyc,repeat)=sqrt(((0.5+s_length(cyc)-(0.5-s_length(cyc)))^2)/12)/0.5;
        %%
        a11=rand(n_m,1);
        initial_value_m=a11/sum(a11);
        initial_value_i=0.8*min(initial_value_m);
        a12=rand(n_m,1);
        A=a12/sum(a12);
        rho0=[initial_value_i;initial_value_m];%
        t0=[0,10000];% 
        %% Tij
        Tij=repmat(ci,1,n_m).*H-repmat(ci',n_m,1).*H';
        %% 
        [t,rho]=ode45(@(t,rho)antagon1(t,rho,ci,ei,ri,n_m,mi,Tij,A),t0,rho0);
        %% 
        aam1 = rho(end-10:end,2:n_m+1);
        aam=length(find(mean(aam1)>1e-4));
        final_species(cyc,repeat)=aam/n_m;
        %% 
        aam2 = rho(end-10:end,1);
        if mean(aam2)>1e-4
            final_species1(cyc,repeat)=1;
        else
            final_species1(cyc,repeat)=0;
        end
    end
    
end
sigma_all=reshape(sigma_all,[],1);
pair_mean=mean(final_species(:,:),2);%
pair_std=std(final_species(:,:),0,2);
pairwise=reshape(final_species(:,:),[],1);
figure(10),plot(sigma_all,pairwise,'go')
save N10
