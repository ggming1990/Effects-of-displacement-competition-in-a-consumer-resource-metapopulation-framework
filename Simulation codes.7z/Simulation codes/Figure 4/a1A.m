clear
clc
tic
n_m=50;% 
rp=20;% 
%% 
f=0.5;%
ci=unifrnd(1,1,n_m,1);% 
m_all=0:0.01:1;% 
ri=unifrnd(1,1,n_m,1);% 
mi=unifrnd(0.1,0.1,n_m,1);% 
ui=unifrnd(0.001,0.001,n_m,1);% 
er_ratio_all=zeros(length(m_all),rp);%er
final_species=zeros(length(m_all),rp);% 
H=triu(ones(n_m),1);H=H+diag(ones(n_m,1)*0.5);
a1=rand(n_m);%
for i=1:n_m-1
    for j=i+1:n_m
        if a1(i,j)<f && rand(1)<0.5
            H(i,j)=0;H(j,i)=1;
        end
    end
end
H1=H-diag(ones(n_m,1)*0.5);%
var=1/n_m*sum((sum(H1,2)-1/n_m*sum(H1(:))).^2);%
if mod(n_m,2)==0 %
    RI=1-((var-0.25)/((n_m^2-1)/12-0.25));
else
    RI=1-(var/((n_m^2-1)/12));
end
for repeat=1:rp
    %% 
    a11=rand(n_m,1);
    initial_value_m=a11/sum(a11);
    initial_value_i=0.1*initial_value_m;
    rho0=[initial_value_i;initial_value_m];%
    t0=[0,10000];% 
    for cyc=1:length(m_all)
        e=m_all(cyc);ei=unifrnd(e,e,n_m,1);%
        er_ratio_all(cyc,repeat)=e;
        %% Tij
        Tij=repmat(ci,1,n_m).*H-repmat(ci',n_m,1).*H';
        %% 
         [t,rho]=ode45(@(t,rho)antagon1(t,rho,Tij,ri,mi,ei,n_m,ui,ci),t0,rho0);
        %% 
        aam1 = rho(end-10:end,n_m+1:2*n_m);
        aam=length(find(mean(aam1)>1e-4));
        final_species(cyc,repeat)=aam/n_m;
    end
    
end
er_ratio_all=reshape(er_ratio_all,[],1);
pair_mean=mean(final_species(:,:),2);%
pair_std=std(final_species(:,:),0,2);
pairwise=reshape(final_species(:,:),[],1);
figure(15),plot(er_ratio_all,pairwise,'go')
save M15

